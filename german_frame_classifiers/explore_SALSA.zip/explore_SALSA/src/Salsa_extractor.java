import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;

import salsa.corpora.elements.*;
import salsa.corpora.noelement.Id;
import salsa.corpora.xmlparser.*;

public class Salsa_extractor {
	
	public static String map_to_string(Map<String, String> fe_map) {
		ArrayList<String> result = new ArrayList<String>();
		for (Map.Entry<String, String> entry : fe_map.entrySet()) {
	        result.add(entry.getKey() + "::" + entry.getValue());
	    }
		return String.join(";;", result);
	}
	
	public static ArrayList<String> get_terminal_ids(Graph graph, Map<String, String> token_ids_to_tokens, String node_id) {
		ArrayList<String> terminal_token_ids = new ArrayList<String>();
		LinkedList<String> id_stack = new LinkedList<String>();
		if (node_id != null) {
			id_stack.add(node_id);
		}
		while (id_stack.size() != 0) {
			String token_id = id_stack.remove();
			if (token_id == null) {
				continue;
			}
			if (token_ids_to_tokens.get(token_id) != null) { // terminal node
				terminal_token_ids.add(token_id);
			}
			else { // non-terminal node
				Nonterminals nonterminals_obj = graph.getNonterminals();
				ArrayList<Nonterminal> nonterminals = nonterminals_obj.getNonterminals();
				Nonterminal curr_nonterminal = null;
				for (Nonterminal nonterminal : nonterminals) {
					Id nonterminal_idref = nonterminal.getId();
					String nonterminal_id = nonterminal_idref.getId();
					if (nonterminal_id.equals(token_id)) {
						curr_nonterminal = nonterminal;
						break;
					}
				}
				if (curr_nonterminal != null) {
					ArrayList<Edge> edges = curr_nonterminal.getEdges();
					LinkedList<String> edge_ids = new LinkedList<String>();
					for (Edge edge : edges) {
						String edge_id = edge.getId().getId();
						edge_ids.add(edge_id);
					}
					edge_ids.addAll(id_stack);
					id_stack = edge_ids;
				}
					
			}
		}
		return terminal_token_ids; // can be empty      
	}
	
	public static void main(String[] args) throws Exception  {
		
		FileWriter fileWriter = new FileWriter("./data/salsa_data_with_targets_inconsistent.txt", true);
	    PrintWriter printWriter = new PrintWriter(fileWriter);
		
		CorpusParser parser = new CorpusParser();
		Corpus corpus = parser.parseCorpusFromFile("./SALSA_2.0/salsa-corpus-2.0/salsa_release.xml");
		Body body = corpus.getBody();
		ArrayList<Sentence> allSentences = body.getSentences();
		//allSentences = new ArrayList(allSentences.subList(0, 15));
		
		//int counter = 0;
		Set<String> fe_labels_set = new HashSet<String>(); 
		for (Sentence sent : allSentences) {
			// extract sentence as a list of tokens plus
			// a list of token ids
			Graph graph = sent.getGraph();
			Terminals terminals_obj = graph.getTerminals();
			ArrayList<Terminal> terminals = terminals_obj.getTerminals();
			
			// initialize two lists to store tokens and their ids as strings
			ArrayList<String> tokens = new ArrayList<String>();
			ArrayList<String> token_ids = new ArrayList<String>();
			Map<String, String> token_ids_to_tokens = new HashMap<String, String>();
			
			for (Terminal terminal : terminals) {
				String token = terminal.getWord();
				Id token_id_obj = terminal.getId();
				String token_id =token_id_obj.getId();
				token_ids_to_tokens.put(token_id, token);
				tokens.add(token);
				token_ids.add(token_id);
			}
			
			// extract frame labels, frame elements and target ids as strings
			Semantics sem = sent.getSem();
			ArrayList<Frames> frames = sem.getFrames(); // this list usually contains only one element
			for (Frames f : frames) {
				ArrayList<Frame> frame = f.getFrames(); // the list of Frame objects of this Frames
				for (Frame fr : frame) {
					String label = fr.getName();
					if (label == null) {
						continue;
					}
					Target target = fr.getTarget();
					ArrayList<Fenode> fenodes = target.getFenodes(); // target can be multi-word
					ArrayList<String> target_ids = new ArrayList<String>();
					for (Fenode fenode : fenodes) {
						Id idref = fenode.getIdref();
						String id = idref.getId();
						ArrayList<String> target_token_ids = get_terminal_ids(graph, token_ids_to_tokens, id);
						for (String target_token_id : target_token_ids) {
							target_ids.add(target_token_id);
						}
					}
					// check if the list of targets is empty, if so, continue
					if (target_ids.size() == 0) {
						continue;
					}
					// extract frame elements
					Map<String, String> fe_map = new HashMap<String, String>(); // map FE label to its actual string value
					ArrayList<FrameElement> fes = fr.getFes();
					for (FrameElement fe : fes) {
						String fe_name = fe.getName();
						fe_labels_set.add(fe_name);
						ArrayList<Fenode> fenodes_fe = fe.getFenodes(); // a FE can be multi-word
						ArrayList<String> fe_tokens = new ArrayList<String>();
						for (Fenode fenode_fe : fenodes_fe) {
							Id fe_idref = fenode_fe.getIdref();
							String fe_id = fe_idref.getId();
							ArrayList<String> terminal_token_ids = get_terminal_ids(graph, token_ids_to_tokens, fe_id);
							if (terminal_token_ids == null) {
								continue;
							}
							// find FE tokens by their ids
							//System.out.println(label+"\t"+fe_name);
							//System.out.println(tokens);
							//System.out.println(token_ids);
							//System.out.println(terminal_token_ids);
							for (String terminal_token_id : terminal_token_ids) {
								fe_tokens.add(token_ids_to_tokens.get(terminal_token_id));
							}
							//System.out.println(fe_tokens);
						}
						// save FE label and FE string pair in the hash map
						fe_map.put(fe_name, String.join(" ", fe_tokens));
					}
					// if targets are not empty, create a token vector
					// containing target markers '[TARGET_START]' and '[TARGET_END]'
					assert target_ids.size() != 0;
					ArrayList<String> tokens_marked = new ArrayList<String>();
					boolean markers_found = false;
					for (int i = 0; i < token_ids.size(); i++) {
						boolean target_found = false;
						for (String target_id : target_ids) {
							if (token_ids.get(i).equals(target_id)) {
								tokens_marked.add("*"); // "[TARGET_START]"
								tokens_marked.add(tokens.get(i));
								tokens_marked.add("*"); // "[TARGET_END]"
                                target_found = true;
                                markers_found = true;
								break;
							}
						}
						if (target_found)
							continue;
						tokens_marked.add(tokens.get(i));
					}
					if (!markers_found)
						continue;
					// get target's lemma
					String target_lemma = target.getLemma();
					// write tokens, frame labels and marked tokens to file
					printWriter.println(String.join(" ", tokens)+"\t"+label+"\t"+target_lemma+"\t"+String.join(" ", tokens_marked));
				}
			}			
		}
		printWriter.close();
	}
}