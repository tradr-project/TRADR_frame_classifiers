import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;

import salsa.corpora.elements.*;
import salsa.corpora.noelement.Id;
import salsa.corpora.xmlparser.*;

public class Salsa_extractor_inconsistent {
	
	public static ArrayList<String> has_duplicates(ArrayList<String> targets_merged) {
		ArrayList<String> dupes = new ArrayList<String>();
		for (int i = 0; i < targets_merged.size(); i++) {
			for (int j = i+1; j < targets_merged.size(); j++) {
				if (targets_merged.get(i).equals(targets_merged.get(j)))
					dupes.add(targets_merged.get(i));
			}
		}
		return dupes;
	}
	
	public static ArrayList<String> extract_targets(ArrayList<Frame> frame) {
		ArrayList<String> targets_merged = new ArrayList<String>();
		for (Frame fr : frame) {
			Target target = fr.getTarget();
			ArrayList<Fenode> fenodes = target.getFenodes(); // target can be multi-word
			ArrayList<String> target_ids = new ArrayList<String>();
			for (Fenode fenode : fenodes) {
				Id idref = fenode.getIdref();
				String id = idref.getId();
				if (id == null) {
					continue;
				}
				target_ids.add(id);
			}
			// check if the list of target ids is empty, if so, continue
			if (target_ids.size() == 0) {
				continue;
			}
			// create a string from separate target ids in case we have a multi-word target
			// these strings will be used to compare targets
			String target_ids_merged = String.join(" ", target_ids);
			targets_merged.add(target_ids_merged);
		}
		return targets_merged;
	}
	
	public static void main(String[] args) throws Exception  {
		
		FileWriter fileWriter = new FileWriter("./data/salsa_data_with_LU_inconsistent.txt", true);
	    PrintWriter printWriter = new PrintWriter(fileWriter);
		
		CorpusParser parser = new CorpusParser();
		Corpus corpus = parser.parseCorpusFromFile("./SALSA_2.0/salsa-corpus-2.0/salsa_release.xml");
		Body body = corpus.getBody();
		ArrayList<Sentence> allSentences = body.getSentences();
		
		//int counter = 0;
		for (Sentence sent : allSentences) {
			// extract sentence as a list of tokens plus
			// a list of token ids
			Graph graph = sent.getGraph();
			Terminals terminals_obj = graph.getTerminals();
			ArrayList<Terminal> terminals = terminals_obj.getTerminals();
			
			// initialize two lists to store tokens and their ids as strings
			ArrayList<String> tokens = new ArrayList<String>();
			ArrayList<String> token_ids = new ArrayList<String>();
			
			for (Terminal terminal : terminals) {
				String token = terminal.getWord();
				Id token_id_obj = terminal.getId();
				String token_id =token_id_obj.getId();
				tokens.add(token);
				token_ids.add(token_id);
			}
			
			// extract frame labels and target ids as strings
			Semantics sem = sent.getSem();
			ArrayList<Frames> frames = sem.getFrames(); // this list usually contains only one element
			for (Frames f : frames) {
				ArrayList<Frame> frame = f.getFrames(); // the list of Frame objects of this Frames
				if (frame.size() < 2) // we are interested only in sentences that have more than one label
					continue; 
				// check if targets are equal; if so, check if frame labels are different
				ArrayList<String> targets_merged = extract_targets(frame);
				// now check targets_merged for duplicates
				ArrayList<String> target_dupes = has_duplicates(targets_merged);
				if (target_dupes.size()==0) // targets are all different
					continue;
				// if targets are equal, check if the frame labels are different
				for (Frame fr : frame) {
					Target target = fr.getTarget();
					ArrayList<Fenode> fenodes = target.getFenodes(); // target can be multi-word
					ArrayList<String> target_ids = new ArrayList<String>();
					for (Fenode fenode : fenodes) {
						Id idref = fenode.getIdref();
						String id = idref.getId();
						if (id == null) {
							continue;
						}
						target_ids.add(id);
					}
					// check if the list of target ids is empty, if so, continue
					if (target_ids.size() == 0) {
						continue;
					}
					// create a string from separate target ids in case we have a multi-word target
					// check if this target id is in the list of duplicates, if so, omit it
					String curr_target = String.join(" ", target_ids);
					if (!target_dupes.contains(curr_target))
						continue;
				
					String label = fr.getName();
					if (label == null) {
						continue;
					}
										
					assert target_ids.size() != 0;
					// if targets are not empty, create a token vector
					// containing target markers '[TARGET_START]' and '[TARGET_END]'
					ArrayList<String> tokens_marked = new ArrayList<String>();
					boolean markers_found = false;
					for (int i = 0; i < token_ids.size(); i++) {
						boolean target_found = false;
						for (String target_id : target_ids) {
							if (token_ids.get(i).equals(target_id)) {
								tokens_marked.add("[TARGET_START]");
								tokens_marked.add(tokens.get(i));
								tokens_marked.add("[TARGET_END]");
                                target_found = true;
                                markers_found = true;
								break;
							}
						}
						if (target_found)
							continue;
						tokens_marked.add(tokens.get(i));
					}
					if (!markers_found)
						continue;
					// get target's lemma
					String target_lemma = target.getLemma();
					// write tokens, frame labels and marked tokens to file
					printWriter.println(String.join(" ", tokens)+"\t"+label+"\t"+target_lemma+"\t"+String.join(" ", tokens_marked));
				}
			}
			//if ((counter % 100) == 0)
			//	System.out.println(counter);
			//counter++;
		}
		printWriter.close();
	}
}